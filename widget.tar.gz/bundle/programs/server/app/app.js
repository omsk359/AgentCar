var require = meteorInstall({"imports":{"api":{"cars.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/cars.js                                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Cars:function(){return Cars}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
var Cars = new Mongo.Collection('cars');                                                                            // 5
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 7
	// This code only runs on the server                                                                               //
	Meteor.publish('cars', function carsPublication() {                                                                // 9
		return Cars.find({ owner: this.userId });                                                                         // 10
	});                                                                                                                // 11
}                                                                                                                   // 12
                                                                                                                    //
Meteor.methods({                                                                                                    // 14
	'cars.insert': function carsInsert(mark, model, equipment, year, engine, color, price, photo) {                    // 15
		check(mark, String);                                                                                              // 16
		check(model, String);                                                                                             // 17
		check(equipment, String);                                                                                         // 18
		check(year, String);                                                                                              // 19
		check(engine, String);                                                                                            // 20
		check(color, String);                                                                                             // 21
		check(price, String);                                                                                             // 22
		check(photo, String);                                                                                             // 23
                                                                                                                    //
		// Make sure the user is logged in before inserting a task                                                        //
		if (!this.userId) {                                                                                               // 26
			throw new Meteor.Error('not-authorized');                                                                        // 27
		}                                                                                                                 // 28
                                                                                                                    //
		Cars.insert({                                                                                                     // 30
			mark: mark,                                                                                                      // 31
			model: model,                                                                                                    // 32
			equipment: equipment,                                                                                            // 33
			year: year,                                                                                                      // 34
			engine: engine,                                                                                                  // 35
			color: color,                                                                                                    // 36
			price: price,                                                                                                    // 37
			photo: photo,                                                                                                    // 38
			//      createdAt: new Date(),                                                                                   //
			owner: this.userId,                                                                                              // 40
			username: Meteor.users.findOne(this.userId).username                                                             // 41
		});                                                                                                               // 30
	},                                                                                                                 // 43
	'cars.remove': function carsRemove(carId) {                                                                        // 44
		check(carId, String);                                                                                             // 45
                                                                                                                    //
		Cars.remove(carId);                                                                                               // 47
	},                                                                                                                 // 48
	'cars.setChecked': function carsSetChecked(carId, setChecked) {                                                    // 49
		check(carId, String);                                                                                             // 50
		check(setChecked, Boolean);                                                                                       // 51
                                                                                                                    //
		Cars.update(carId, { $set: { checked: setChecked } });                                                            // 53
	},                                                                                                                 // 54
	'cars.find': function carsFind(token) {                                                                            // 55
		Meteor.publish('carz', function () {                                                                              // 56
			return Cars.find({ owner: token });                                                                              // 57
		});                                                                                                               // 58
	}                                                                                                                  // 59
});                                                                                                                 // 14
                                                                                                                    //
// if (Meteor.isServer) {                                                                                           //
//   // This code only runs on the server                                                                           //
//   Meteor.publish('cars', function carsPublication() {                                                            //
//     return Cars.find();                                                                                          //
//   });                                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/cars.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../imports/api/cars.js');
                                                                                                                    //
Meteor.startup(function () {                                                                                        // 3
  // code to run on server at startup                                                                               //
});                                                                                                                 // 5
                                                                                                                    //
                                                                                                                    // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
