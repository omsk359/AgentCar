var require = meteorInstall({"imports":{"api":{"cars.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/cars.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Cars:function(){return Cars}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                      //
var Cars = new Mongo.Collection('cars');                                                                              // 3
                                                                                                                      //
// if (Meteor.isServer) {                                                                                             //
//   // This code only runs on the server                                                                             //
//   Meteor.publish('cars', function carsPublication() {                                                              //
//     return Cars.find();                                                                                            //
//   });                                                                                                              //
//                                                                                                                    //
//   Meteor.publish('recentCars', function() {                                                                        //
//     return Cars.find({                                                                                             //
//       sort: {                                                                                                      //
//         price: 1                                                                                                   //
//       },                                                                                                           //
//       limit: 20                                                                                                    //
//     });                                                                                                            //
//   });                                                                                                              //
// }                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/cars.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../imports/api/cars.js');   // 1
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 3
  // code to run on server at startup                                                                                 //
});                                                                                                                   // 5
                                                                                                                      //
                                                                                                                      // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
